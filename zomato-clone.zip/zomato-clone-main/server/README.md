# API Planning
 ## Schemas 
  - Food ( food items and their details)
  - Restaurants ( restaurants and their details) 
  - Menu ( Menu and its details )
  - Order ( Order and its details)
  - Image ( Storing all the images related to the project)
  - Review ( Storing the list of reviews - Dining/ Delivery)
  - User ( User related deatils, username, email, password)