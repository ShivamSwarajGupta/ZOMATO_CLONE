export const GET_USER = "GET_USER"; // GET GENERAL USER DETAIlS FOR REVIEW
export const SELF = "SELF"; // PERSONAL DETAILS
export const AUTH_USER = "AUTH_USER ";
export const CLEAR_USER = "CLEAR_USER"; // FOR SIGN OUT
